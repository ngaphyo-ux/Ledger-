ALTER TABLE `ledger_entries` ADD COLUMN `clientMutationId` varchar(64);
--> statement-breakpoint
CREATE UNIQUE INDEX `ledger_user_mutation_unique` ON `ledger_entries` (`userId`, `clientMutationId`);
