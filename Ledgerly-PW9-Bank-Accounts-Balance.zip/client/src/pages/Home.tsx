import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleDollarSign,
  CloudOff,
  Download,
  FileDown,
  Edit3,
  Landmark,
  LayoutDashboard,
  ListFilter,
  LogOut,
  Menu,
  Plus,
  RefreshCw,
  ShieldCheck,
  Tag,
  WalletCards,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { getOverviewSnapshot, listPendingEntries, removePendingEntry, saveOverviewSnapshot, savePendingEntry, type OfflineEntry } from "@/lib/offlineEntries";
import { toast } from "sonner";

type View = "overview" | "entries" | "accounts" | "categories";
type EntryFlow = "in" | "out";
type EntryType = "statement" | "cash";
type CategoryType = "income" | "expense" | "both";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type EntryDraft = {
  id?: number;
  accountId: string;
  categoryId: string;
  entryType: EntryType;
  flow: EntryFlow;
  amount: string;
  entryDate: string;
  description: string;
  remarks: string;
};

type AccountDraft = {
  id?: number;
  name: string;
  institution: string;
  lastFour: string;
  openingBalance: string;
};

type CategoryDraft = {
  id?: number;
  name: string;
  type: CategoryType;
  color: string;
};

const today = new Date().toISOString().slice(0, 10);
const emptyEntry: EntryDraft = {
  accountId: "",
  categoryId: "",
  entryType: "cash",
  flow: "out",
  amount: "",
  entryDate: today,
  description: "",
  remarks: "",
};
const emptyAccount: AccountDraft = {
  name: "",
  institution: "",
  lastFour: "",
  openingBalance: "0",
};
const emptyCategory: CategoryDraft = {
  name: "",
  type: "both",
  color: "#F4B942",
};

function formatAmount(value: number | string) {
  const amount = Number(value || 0);
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function initials(name?: string | null) {
  return (name || "You")
    .split(" ")
    .map(part => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(
    new Date(`${value}T12:00:00`)
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="field-label">{children}</label>;
}

function EmptyState({ title, description, action }: { title: string; description: string; action?: React.ReactNode }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon"><WalletCards size={20} /></div>
      <div>
        <p className="empty-state-title">{title}</p>
        <p className="empty-state-copy">{description}</p>
      </div>
      {action}
    </div>
  );
}

export default function Home() {
  const { user, loading: authLoading, logout } = useAuth();
  const [activeView, setActiveView] = useState<View>("overview");
  const [entryDraft, setEntryDraft] = useState<EntryDraft>(emptyEntry);
  const [accountDraft, setAccountDraft] = useState<AccountDraft>(emptyAccount);
  const [categoryDraft, setCategoryDraft] = useState<CategoryDraft>(emptyCategory);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isOnline, setIsOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine);
  const [pendingEntries, setPendingEntries] = useState<OfflineEntry[]>([]);
  const [isSyncingQueue, setIsSyncingQueue] = useState(false);
  const syncLock = useRef(false);

  const utils = trpc.useUtils();
  const overviewQuery = trpc.finance.overview.useQuery(undefined, {
    enabled: Boolean(user),
    retry: false,
    refetchOnWindowFocus: false,
  });

  const refresh = () => utils.finance.overview.invalidate();
  const createEntry = trpc.finance.createEntry.useMutation({ onSuccess: refresh });
  const updateEntry = trpc.finance.updateEntry.useMutation({ onSuccess: refresh });
  const createAccount = trpc.finance.createAccount.useMutation({ onSuccess: refresh });
  const updateAccount = trpc.finance.updateAccount.useMutation({ onSuccess: refresh });
  const createCategory = trpc.finance.createCategory.useMutation({ onSuccess: refresh });
  const updateCategory = trpc.finance.updateCategory.useMutation({ onSuccess: refresh });

  const reloadPendingEntries = async () => {
    if (!user?.id) return;
    try { setPendingEntries(await listPendingEntries(user.id)); }
    catch (error) { console.warn("[Offline queue] Could not read pending transactions", error); }
  };

  const syncPendingEntries = async () => {
    if (!user?.id || !navigator.onLine || syncLock.current) return;
    syncLock.current = true;
    setIsSyncingQueue(true);
    try {
      const queued = await listPendingEntries(user.id);
      for (const item of queued) {
        try {
          await createEntry.mutateAsync({ ...item.payload, clientMutationId: item.mutationId });
          await removePendingEntry(item.mutationId);
        } catch (error) {
          console.warn("[Offline queue] Sync paused; transaction remains queued", error);
          break;
        }
      }
      await reloadPendingEntries();
    } finally {
      syncLock.current = false;
      setIsSyncingQueue(false);
    }
  };

  const overview = overviewQuery.data;
  useEffect(() => {
    if (user?.id && overview) void saveOverviewSnapshot(user.id, overview).catch(error => console.warn("[Offline cache] Could not save ledger snapshot", error));
  }, [user?.id, overview]);
  useEffect(() => {
    if (!user?.id || navigator.onLine || overview) return;
    void getOverviewSnapshot<typeof overview>(user.id).then(snapshot => {
      if (snapshot) utils.finance.overview.setData(undefined, snapshot);
    }).catch(error => console.warn("[Offline cache] Could not restore ledger snapshot", error));
  }, [user?.id, isOnline]);
  const accounts = overview?.accounts ?? [];
  const categories = overview?.categories ?? [];
  const entries = overview?.entries ?? [];

  const totals = useMemo(() => {
    const totalIn = entries.filter(entry => entry.flow === "in").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const totalOut = entries.filter(entry => entry.flow === "out").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const accountBalances = accounts.map(account => {
      const movement = entries
        .filter(entry => entry.accountId === account.id)
        .reduce((sum, entry) => sum + (entry.flow === "in" ? Number(entry.amount) : -Number(entry.amount)), 0);
      return { ...account, balance: Number(account.openingBalance) + movement };
    });
    return { totalIn, totalOut, net: totalIn - totalOut, accountBalances };
  }, [accounts, entries]);

  useEffect(() => { void reloadPendingEntries(); }, [user?.id]);

  useEffect(() => {
    if (isOnline && pendingEntries.length > 0) void syncPendingEntries();
  }, [isOnline, pendingEntries.length, user?.id]);

  useEffect(() => {
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  const exportTransactionsPdf = () => {
    const escapeHtml = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]!));
    const queuedRows = pendingEntries.map(item => ({
      entryDate: item.payload.entryDate,
      description: item.payload.description,
      accountName: accounts.find(account => account.id === item.payload.accountId)?.name || "Account",
      categoryName: categories.find(category => category.id === item.payload.categoryId)?.name || "Uncategorized",
      flow: item.payload.flow,
      amount: item.payload.amount,
      status: "Waiting to sync",
    }));
    const reportRows = [
      ...entries.map(entry => ({ ...entry, status: "Synced" })),
      ...queuedRows,
    ];
    const rows = reportRows.map(entry => `<tr><td>${escapeHtml(formatDate(entry.entryDate))}</td><td>${escapeHtml(entry.description)}</td><td>${escapeHtml(entry.accountName || "Unassigned")}</td><td>${escapeHtml(entry.categoryName || "Uncategorized")}</td><td>${entry.flow === "in" ? "Income" : "Expense"}</td><td class="amount ${entry.flow}">${entry.flow === "in" ? "+" : "−"} ${escapeHtml(formatAmount(entry.amount))}</td><td>${escapeHtml(entry.status)}</td></tr>`).join("");
    const totalIn = reportRows.filter(entry => entry.flow === "in").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const totalOut = reportRows.filter(entry => entry.flow === "out").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const printWindow = window.open("", "_blank");
    if (!printWindow) { toast.error("Allow pop-ups to export your PDF."); return; }
    printWindow.document.write(`<!doctype html><html><head><title>Ledgerly Transactions</title><meta charset="utf-8"><style>body{font:12px Arial,sans-serif;color:#172033;padding:28px}h1{font-size:22px;margin:0 0 6px}.muted{color:#64748b;margin-bottom:22px}.summary{display:flex;gap:24px;margin:0 0 20px;padding:14px;background:#f1f5f9;border-radius:8px}.summary strong{display:block;margin-top:4px}table{width:100%;border-collapse:collapse;font-size:10px}th,td{padding:9px 7px;border-bottom:1px solid #e2e8f0;text-align:left}th{background:#f8fafc}.amount{text-align:right;white-space:nowrap;font-weight:bold}.in{color:#047857}.out{color:#be123c}@media print{body{padding:0}@page{size:landscape;margin:12mm}}</style></head><body><h1>Ledgerly · Transaction Report</h1><div class="muted">Generated ${escapeHtml(new Date().toLocaleString())} · ${reportRows.length} transactions</div><div class="summary"><div>Money in<strong>${escapeHtml(formatAmount(totalIn))}</strong></div><div>Money out<strong>${escapeHtml(formatAmount(totalOut))}</strong></div><div>Net movement<strong>${escapeHtml(formatAmount(totalIn-totalOut))}</strong></div></div><table><thead><tr><th>Date</th><th>Description</th><th>Account</th><th>Category</th><th>Type</th><th style="text-align:right">Amount</th><th>Sync status</th></tr></thead><tbody>${rows || "<tr><td colspan='7'>No transactions recorded.</td></tr>"}</tbody></table></body></html>`);
    printWindow.document.close();
    printWindow.focus();
    window.setTimeout(() => printWindow.print(), 350);
  };

  const handleInstall = async () => {
    if (!installPrompt) {
      toast.info("Use your browser menu and choose Add to Home Screen to install Ledgerly.");
      return;
    }
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") toast.success("Ledgerly is ready on your home screen.");
    setInstallPrompt(null);
  };

  const resetEntry = () => setEntryDraft({ ...emptyEntry, accountId: accounts[0] ? String(accounts[0].id) : "" });
  const resetAccount = () => setAccountDraft(emptyAccount);
  const resetCategory = () => setCategoryDraft(emptyCategory);

  const handleEntrySubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!entryDraft.accountId) return toast.error("Add a bank account before recording a transaction.");
    if (!entryDraft.amount || Number(entryDraft.amount) <= 0) return toast.error("Enter an amount greater than zero.");
    const payload = {
      accountId: Number(entryDraft.accountId),
      categoryId: entryDraft.categoryId ? Number(entryDraft.categoryId) : null,
      entryType: entryDraft.entryType,
      flow: entryDraft.flow,
      amount: entryDraft.amount,
      entryDate: entryDraft.entryDate,
      description: entryDraft.description.trim(),
      remarks: entryDraft.remarks.trim() || null,
    };
    if (!payload.description) return toast.error("Add a short description for this record.");

    const onSuccess = () => {
      toast.success(entryDraft.id ? "Record updated." : "Record added.");
      resetEntry();
    };
    if (entryDraft.id) {
      updateEntry.mutate({ id: entryDraft.id, data: payload }, { onSuccess });
    } else {
      const mutationId = typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `ledger-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      if (!navigator.onLine) {
        if (!user?.id) return toast.error("Sign in is required before saving offline transactions.");
        savePendingEntry({ mutationId, userId: user.id, payload, createdAt: Date.now() })
          .then(reloadPendingEntries)
          .then(() => { toast.success("Saved on this device. It will sync when you are online."); resetEntry(); })
          .catch(() => toast.error("This browser could not save the transaction offline."));
      } else {
        createEntry.mutate({ ...payload, clientMutationId: mutationId }, { onSuccess, onError: async () => {
          if (!user?.id) return;
          try {
            await savePendingEntry({ mutationId, userId: user.id, payload, createdAt: Date.now() });
            await reloadPendingEntries();
            toast.info("Connection interrupted. Transaction saved on this device for retry.");
            resetEntry();
          } catch { toast.error("Could not save this transaction for offline sync. Please try again."); }
        } });
      }
    }
  };

  const handleAccountSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!accountDraft.name.trim() || !accountDraft.institution.trim()) return toast.error("Add an account name and institution.");
    const payload = {
      name: accountDraft.name.trim(),
      institution: accountDraft.institution.trim(),
      lastFour: accountDraft.lastFour.trim() || null,
      openingBalance: accountDraft.openingBalance || "0",
    };
    const onSuccess = () => {
      toast.success(accountDraft.id ? "Bank account updated." : "Bank account added.");
      resetAccount();
    };
    if (accountDraft.id) updateAccount.mutate({ id: accountDraft.id, data: payload }, { onSuccess });
    else createAccount.mutate(payload, { onSuccess });
  };

  const handleCategorySubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!categoryDraft.name.trim()) return toast.error("Name this category first.");
    const payload = { ...categoryDraft, name: categoryDraft.name.trim() };
    const onSuccess = () => {
      toast.success(categoryDraft.id ? "Category updated." : "Category added.");
      resetCategory();
    };
    if (categoryDraft.id) updateCategory.mutate({ id: categoryDraft.id, data: payload }, { onSuccess });
    else createCategory.mutate(payload, { onSuccess });
  };

  if (authLoading) {
    return <div className="app-loading"><RefreshCw className="spin" size={22} /><span>Loading your Ledgerly workspace…</span></div>;
  }

  if (!user) {
    return (
      <div className="login-shell">
        <div className="login-grid" />
        <div className="login-card">
          <div className="brand-lockup"><div className="brand-mark"><Landmark size={22} /></div><span>LEDGERLY</span></div>
          <div className="login-kicker">PRIVATE FINANCE OPERATING SYSTEM</div>
          <h1>See every account.<br /><em>Know your position.</em></h1>
          <p className="login-copy">Bring bank statements, cash movement, categories, and remarks into one calm control panel built for your pocket.</p>
          <Button className="login-button" size="lg" onClick={() => startLogin()}><ShieldCheck size={18} /> Sign in securely</Button>
          <div className="login-note"><Check size={14} /> Your records stay scoped to your signed-in account.</div>
        </div>
      </div>
    );
  }

  if (overviewQuery.isLoading) {
    return <div className="app-loading"><RefreshCw className="spin" size={22} /><span>Loading your ledger…</span></div>;
  }

  const navItems: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "entries", label: "Activity", icon: ListFilter },
    { id: "accounts", label: "Accounts", icon: Landmark },
    { id: "categories", label: "Categories", icon: Tag },
  ];

  const renderEntryForm = () => {
    const isSaving = createEntry.isPending || updateEntry.isPending;
    const compatibleCategories = categories.filter(category => category.type === "both" || (entryDraft.flow === "in" ? category.type === "income" : category.type === "expense"));
    return (
      <Card className="composer-card" id="entry-form">
        <CardHeader className="composer-header">
          <div><div className="eyebrow">{entryDraft.id ? "EDIT RECORD" : "QUICK CAPTURE"}</div><CardTitle>{entryDraft.id ? "Update movement" : "Add a transaction"}</CardTitle></div>
          {entryDraft.id && <Button variant="ghost" size="icon" onClick={resetEntry} aria-label="Cancel editing"><X size={18} /></Button>}
        </CardHeader>
        <CardContent>
          <form className="form-stack" onSubmit={handleEntrySubmit}>
            <div className="segmented-control">
              <button type="button" className={entryDraft.entryType === "cash" ? "selected" : ""} onClick={() => setEntryDraft(prev => ({ ...prev, entryType: "cash" }))}><Banknote size={15} /> Cash movement</button>
              <button type="button" className={entryDraft.entryType === "statement" ? "selected" : ""} onClick={() => setEntryDraft(prev => ({ ...prev, entryType: "statement" }))}><Landmark size={15} /> Bank statement</button>
            </div>
            <div className="flow-toggle">
              <button type="button" className={entryDraft.flow === "in" ? "in selected" : "in"} onClick={() => setEntryDraft(prev => ({ ...prev, flow: "in", categoryId: "" }))}><ArrowDownLeft size={16} /> Cash in</button>
              <button type="button" className={entryDraft.flow === "out" ? "out selected" : "out"} onClick={() => setEntryDraft(prev => ({ ...prev, flow: "out", categoryId: "" }))}><ArrowUpRight size={16} /> Cash out</button>
            </div>
            <div className="form-grid two">
              <div><FieldLabel>Amount</FieldLabel><div className="amount-input"><span>¤</span><input required inputMode="decimal" type="number" min="0.01" step="0.01" placeholder="0.00" value={entryDraft.amount} onChange={event => setEntryDraft(prev => ({ ...prev, amount: event.target.value }))} /></div></div>
              <div><FieldLabel>Date</FieldLabel><input required className="field-input" type="date" value={entryDraft.entryDate} onChange={event => setEntryDraft(prev => ({ ...prev, entryDate: event.target.value }))} /></div>
            </div>
            <div className="form-grid two">
              <div><FieldLabel>Bank account</FieldLabel><select required className="field-select" value={entryDraft.accountId} onChange={event => setEntryDraft(prev => ({ ...prev, accountId: event.target.value }))}><option value="">Select account</option>{accounts.map(account => <option key={account.id} value={account.id}>{account.name} · {account.institution}</option>)}</select></div>
              <div><FieldLabel>Category</FieldLabel><select className="field-select" value={entryDraft.categoryId} onChange={event => setEntryDraft(prev => ({ ...prev, categoryId: event.target.value }))}><option value="">Uncategorized</option>{compatibleCategories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}</select></div>
            </div>
            <div><FieldLabel>{entryDraft.entryType === "statement" ? "Statement description" : "What was this for?"}</FieldLabel><input required className="field-input" placeholder={entryDraft.entryType === "statement" ? "e.g. ATM withdrawal, salary credit" : "e.g. Lunch, freelance payment"} value={entryDraft.description} onChange={event => setEntryDraft(prev => ({ ...prev, description: event.target.value }))} /></div>
            <div><FieldLabel>Remarks <span className="optional">OPTIONAL</span></FieldLabel><textarea className="field-input field-textarea" rows={3} placeholder="Add context for your future self…" value={entryDraft.remarks} onChange={event => setEntryDraft(prev => ({ ...prev, remarks: event.target.value }))} /></div>
            <Button type="submit" className="wide-button" disabled={isSaving || accounts.length === 0}>{isSaving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{entryDraft.id ? "Update record" : "Save record"}</Button>
            {accounts.length === 0 && <p className="form-hint">Add a bank account first, then you can assign records to it.</p>}
          </form>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="app-shell">
      <aside className="desktop-rail">
        <div className="rail-brand"><div className="brand-mark"><Landmark size={18} /></div><span>LEDGERLY</span></div>
        <div className="rail-section-label">WORKSPACE</div>
        <nav className="rail-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={activeView === item.id ? "active" : ""} onClick={() => setActiveView(item.id)}><Icon size={17} /><span>{item.label}</span>{activeView === item.id && <ChevronRight className="nav-arrow" size={15} />}</button>; })}</nav>
        <div className="rail-spacer" />
        <div className="rail-status"><span className={isOnline ? "status-dot online" : "status-dot"} />{isOnline ? "SYNC READY" : "OFFLINE MODE"}<span className="status-line" /></div>
        <button className="rail-account" onClick={() => logout()}><span className="avatar">{initials(user.name)}</span><span className="account-copy"><strong>{user.name || "My workspace"}</strong><small>Sign out</small></span><LogOut size={15} /></button>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <div className="mobile-brand">
            <div className="brand-mark"><Landmark size={17} /></div>
            <span>LEDGERLY</span>
          </div>
          <div className="topbar-meta">
            <span className={isOnline ? "online-label" : "offline-label"}>
              {isOnline ? <Check size={13} /> : <CloudOff size={13} />}
              {isOnline ? (pendingEntries.length ? `${pendingEntries.length} WAITING TO SYNC` : "ALL SYSTEMS SYNCED") : "WORKING OFFLINE"}
            </span>
            <Button variant="outline" size="sm" onClick={handleInstall}>
              <Download size={15} /> Install app
            </Button>
            <button className="topbar-avatar" onClick={() => logout()}>{initials(user.name)}</button>
          </div>
        </header>
        <div className="mobile-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={activeView === item.id ? "active" : ""} onClick={() => setActiveView(item.id)}><Icon size={17} /><span>{item.label}</span></button>; })}</div>

        <div className="page-wrap">
          <section className="page-heading"><div><p className="eyebrow">PERSONAL FINANCE / {new Intl.DateTimeFormat("en", { month: "short", year: "numeric" }).format(new Date()).toUpperCase()}</p><h1>{activeView === "overview" ? "PW9 Bank Accounts Balance" : activeView === "entries" ? "Activity log" : activeView === "accounts" ? "Bank accounts" : "Categories"}</h1><p className="heading-copy">{activeView === "overview" ? "A clean read on where your money stands today." : activeView === "entries" ? "Bank statements and cash movements, all in one timeline." : activeView === "accounts" ? "Keep every individual account visible and assignable." : "Make your own language for cash in and cash out."}</p></div><div className="heading-actions"><Button variant="outline" size="sm" onClick={() => { void syncPendingEntries(); void refresh(); }} disabled={overviewQuery.isFetching || isSyncingQueue}><RefreshCw className={overviewQuery.isFetching ? "spin" : ""} size={15} /> Sync</Button><Button size="sm" onClick={() => { setActiveView("entries"); resetEntry(); document.getElementById("entry-form")?.scrollIntoView({ behavior: "smooth" }); }}><Plus size={15} /> Add record</Button></div></section>

          {overviewQuery.error && !overview && <div className="error-strip">We could not load your ledger. Refresh to retry. <button onClick={() => refresh()}>Try again</button></div>}

          {activeView === "overview" && <>
            <section className="overview-balance-section">
              <Card className="overview-balance-card">
                <CardContent>
                  <div className="overview-balance-top"><div><span className="overview-kicker">TOTAL BALANCE</span><p className="overview-balance-caption">Your money across all accounts</p></div><span className="overview-balance-icon"><CircleDollarSign size={22} /></span></div>
                  <div className="overview-balance-value">¤ {formatAmount(totals.accountBalances.reduce((sum, account) => sum + account.balance, 0))}</div>
                  <div className="overview-balance-foot">{accounts.length} account{accounts.length === 1 ? "" : "s"} included in your total</div>
                </CardContent>
              </Card>
              <div className="overview-flow-grid">
                <Card className="overview-flow-card income-card"><CardContent><div className="overview-flow-heading"><span className="overview-flow-icon"><ArrowDownLeft size={18} /></span><span>INCOME</span></div><div className="overview-flow-value">¤ {formatAmount(totals.totalIn)}</div><p>All recorded money in</p></CardContent></Card>
                <Card className="overview-flow-card expense-card"><CardContent><div className="overview-flow-heading"><span className="overview-flow-icon"><ArrowUpRight size={18} /></span><span>EXPENSES</span></div><div className="overview-flow-value">¤ {formatAmount(totals.totalOut)}</div><p>All recorded money out</p></CardContent></Card>
              </div>
            </section>

            <Card className="panel-card overview-accounts-card">
              <CardHeader className="panel-heading"><div><div className="eyebrow">YOUR MONEY, ACCOUNT BY ACCOUNT</div><CardTitle>Individual account balances</CardTitle></div><button className="text-action" onClick={() => setActiveView("accounts")}>Manage accounts <ChevronRight size={14} /></button></CardHeader>
              <CardContent className="flush-content">{accounts.length === 0 ? <EmptyState title="No accounts yet" description="Add your first bank or cash account to see its balance here." action={<Button size="sm" onClick={() => setActiveView("accounts")}><Plus size={14} /> Add account</Button>} /> : <div className="overview-account-grid">{totals.accountBalances.map(account => <div className="overview-account-item" key={account.id}><span className="overview-account-icon"><Landmark size={18} /></span><span className="overview-account-details"><strong>{account.name}</strong><small>{account.institution}{account.lastFour ? ` ··${account.lastFour}` : ""}</small></span><strong className="overview-account-amount">¤ {formatAmount(account.balance)}</strong></div>)}</div>}</CardContent>
            </Card>

            <section className="dashboard-grid overview-lower-grid"><div className="dashboard-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">LATEST SIGNALS</div><CardTitle>Recent activity</CardTitle></div><button className="text-action" onClick={() => setActiveView("entries")}>View all <ChevronRight size={14} /></button></CardHeader><CardContent className="flush-content">{entries.length === 0 ? <EmptyState title="Your timeline is clear" description="Add a bank account, then capture your first statement or cash movement." action={<Button size="sm" onClick={() => setActiveView("accounts")}><Plus size={14} /> Add account</Button>} /> : <div className="entry-list">{entries.slice(0, 6).map(entry => <EntryRow key={entry.id} entry={entry} onEdit={() => { setEntryDraft({ id: entry.id, accountId: String(entry.accountId), categoryId: entry.categoryId ? String(entry.categoryId) : "", entryType: entry.entryType, flow: entry.flow, amount: String(entry.amount), entryDate: entry.entryDate, description: entry.description, remarks: entry.remarks || "" }); setActiveView("entries"); setTimeout(() => document.getElementById("entry-form")?.scrollIntoView({ behavior: "smooth" }), 50); }} />)}</div>}</CardContent></Card></div><div className="dashboard-side">{renderEntryForm()}</div></section>
          </>}

          {activeView === "entries" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">LEDGER TIMELINE</div><CardTitle>All activity</CardTitle></div><div className="activity-actions"><div className="entry-count">{entries.length} RECORD{entries.length === 1 ? "" : "S"}</div><Button variant="outline" size="sm" onClick={exportTransactionsPdf}><FileDown size={15} /> Export PDF</Button></div></CardHeader><CardContent className="flush-content">{pendingEntries.length > 0 && <div className="pending-sync-banner"><CloudOff size={15} /> {isSyncingQueue ? "Syncing saved transactions…" : `${pendingEntries.length} transaction${pendingEntries.length === 1 ? "" : "s"} saved on this device and waiting to sync.`}</div>}{entries.length === 0 && pendingEntries.length === 0 ? <EmptyState title="No activity recorded" description="Use the capture panel to add a bank statement or cash movement." /> : <div className="entry-list">{pendingEntries.map(item => <div className="entry-row pending-entry" key={item.mutationId}><span className={`entry-icon ${item.payload.flow}`}><CloudOff size={15} /></span><span className="entry-info"><strong>{item.payload.description}</strong><small>{accounts.find(account => account.id === item.payload.accountId)?.name || "Account"} · {categories.find(category => category.id === item.payload.categoryId)?.name || "Uncategorized"} · Waiting to sync</small></span><strong className={`entry-amount ${item.payload.flow}`}>{item.payload.flow === "in" ? "+" : "−"}¤ {formatAmount(item.payload.amount)}</strong></div>)}{entries.map(entry => <EntryRow key={entry.id} entry={entry} onEdit={() => setEntryDraft({ id: entry.id, accountId: String(entry.accountId), categoryId: entry.categoryId ? String(entry.categoryId) : "", entryType: entry.entryType, flow: entry.flow, amount: String(entry.amount), entryDate: entry.entryDate, description: entry.description, remarks: entry.remarks || "" })} />)}</div>}</CardContent></Card></div><div className="content-side">{renderEntryForm()}</div></section>}

          {activeView === "accounts" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">CONNECTED ACCOUNTS</div><CardTitle>Every bank in one view</CardTitle></div><div className="entry-count">{accounts.length} ACCOUNT{accounts.length === 1 ? "" : "S"}</div></CardHeader><CardContent className="flush-content">{accounts.length === 0 ? <EmptyState title="Start with an account" description="Add your current or savings account so every future record has a home." /> : <div className="account-cards">{totals.accountBalances.map(account => <div className="account-card" key={account.id}><div className="account-card-top"><span className="account-icon large"><Landmark size={19} /></span><button className="icon-button" aria-label={`Edit ${account.name}`} onClick={() => setAccountDraft({ id: account.id, name: account.name, institution: account.institution, lastFour: account.lastFour || "", openingBalance: String(account.openingBalance) })}><Edit3 size={15} /></button></div><div className="account-card-name">{account.name}</div><div className="account-card-institution">{account.institution}{account.lastFour ? ` ··${account.lastFour}` : ""}</div><div className="account-card-balance">¤ {formatAmount(account.balance)}</div><div className="account-card-foot"><span>Opening balance</span><span>¤ {formatAmount(account.openingBalance)}</span></div></div>)}</div>}</CardContent></Card></div><div className="content-side"><AccountForm draft={accountDraft} setDraft={setAccountDraft} onSubmit={handleAccountSubmit} onCancel={resetAccount} saving={createAccount.isPending || updateAccount.isPending} /></div></section>}

          {activeView === "categories" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">YOUR VOCABULARY</div><CardTitle>Categories</CardTitle></div><div className="entry-count">{categories.length} TAG{categories.length === 1 ? "" : "S"}</div></CardHeader><CardContent className="flush-content"><div className="category-list">{categories.map(category => <div className="category-row" key={category.id}><span className="category-dot" style={{ background: category.color }} /><span className="category-name">{category.name}</span><span className={`category-type ${category.type}`}>{category.type === "both" ? "IN + OUT" : category.type.toUpperCase()}</span><button className="icon-button" onClick={() => setCategoryDraft({ id: category.id, name: category.name, type: category.type, color: category.color })} aria-label={`Edit ${category.name}`}><Edit3 size={15} /></button></div>)}</div></CardContent></Card></div><div className="content-side"><CategoryForm draft={categoryDraft} setDraft={setCategoryDraft} onSubmit={handleCategorySubmit} onCancel={resetCategory} saving={createCategory.isPending || updateCategory.isPending} /></div></section>}
        </div>
      </main>
    </div>
  );
}

function EntryRow({ entry, onEdit }: { entry: { id: number; accountName: string | null; categoryName: string | null; categoryColor: string | null; entryType: EntryType; flow: EntryFlow; amount: string; entryDate: string; description: string; remarks: string | null }; onEdit: () => void }) {
  return <div className="entry-row"><span className={`entry-icon ${entry.flow}`}><>{entry.flow === "in" ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}</></span><span className="entry-info"><strong>{entry.description}</strong><small>{entry.accountName || "Unassigned account"} · {entry.categoryName || "Uncategorized"} · {entry.entryType === "statement" ? "Statement" : "Cash"}</small></span><span className="entry-date">{formatDate(entry.entryDate)}</span><strong className={`entry-amount ${entry.flow}`}>{entry.flow === "in" ? "+" : "−"}¤ {formatAmount(entry.amount)}</strong><button className="icon-button edit-entry" onClick={onEdit} aria-label={`Edit ${entry.description}`}><Edit3 size={14} /></button></div>;
}

function AccountForm({ draft, setDraft, onSubmit, onCancel, saving }: { draft: AccountDraft; setDraft: (value: AccountDraft) => void; onSubmit: (event: FormEvent) => void; onCancel: () => void; saving: boolean }) {
  return <Card className="composer-card"><CardHeader className="composer-header"><div><div className="eyebrow">{draft.id ? "EDIT ACCOUNT" : "NEW ACCOUNT"}</div><CardTitle>{draft.id ? "Update account" : "Add bank account"}</CardTitle></div>{draft.id && <Button variant="ghost" size="icon" onClick={onCancel}><X size={18} /></Button>}</CardHeader><CardContent><form className="form-stack" onSubmit={onSubmit}><div><FieldLabel>Account name</FieldLabel><input required className="field-input" placeholder="e.g. Daily spending" value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></div><div><FieldLabel>Bank or institution</FieldLabel><input required className="field-input" placeholder="e.g. Metro Bank" value={draft.institution} onChange={event => setDraft({ ...draft, institution: event.target.value })} /></div><div className="form-grid two"><div><FieldLabel>Last 4 digits <span className="optional">OPTIONAL</span></FieldLabel><input className="field-input" inputMode="numeric" maxLength={4} placeholder="4821" value={draft.lastFour} onChange={event => setDraft({ ...draft, lastFour: event.target.value.replace(/\D/g, "").slice(0, 4) })} /></div><div><FieldLabel>Opening balance</FieldLabel><input required className="field-input" inputMode="decimal" type="number" step="0.01" min="0" value={draft.openingBalance} onChange={event => setDraft({ ...draft, openingBalance: event.target.value })} /></div></div><Button type="submit" className="wide-button" disabled={saving}>{saving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{draft.id ? "Update account" : "Save account"}</Button></form></CardContent></Card>;
}

function CategoryForm({ draft, setDraft, onSubmit, onCancel, saving }: { draft: CategoryDraft; setDraft: (value: CategoryDraft) => void; onSubmit: (event: FormEvent) => void; onCancel: () => void; saving: boolean }) {
  return <Card className="composer-card"><CardHeader className="composer-header"><div><div className="eyebrow">{draft.id ? "EDIT CATEGORY" : "NEW CATEGORY"}</div><CardTitle>{draft.id ? "Update category" : "Add category"}</CardTitle></div>{draft.id && <Button variant="ghost" size="icon" onClick={onCancel}><X size={18} /></Button>}</CardHeader><CardContent><form className="form-stack" onSubmit={onSubmit}><div><FieldLabel>Category name</FieldLabel><input required className="field-input" placeholder="e.g. Subscriptions" value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></div><div><FieldLabel>Used for</FieldLabel><select className="field-select" value={draft.type} onChange={event => setDraft({ ...draft, type: event.target.value as CategoryType })}><option value="both">Cash in + cash out</option><option value="income">Cash in only</option><option value="expense">Cash out only</option></select></div><div><FieldLabel>Accent color</FieldLabel><div className="color-row"><input className="color-input" type="color" value={draft.color} onChange={event => setDraft({ ...draft, color: event.target.value })} /><span>{draft.color}</span></div></div><Button type="submit" className="wide-button" disabled={saving}>{saving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{draft.id ? "Update category" : "Save category"}</Button></form></CardContent></Card>;
}
