export type OfflineEntry = {
  mutationId: string;
  userId: number;
  payload: {
    accountId: number;
    categoryId: number | null;
    entryType: "statement" | "cash";
    flow: "in" | "out";
    amount: string;
    entryDate: string;
    description: string;
    remarks: string | null;
  };
  createdAt: number;
};

const DB_NAME = "ledgerly-offline-v1";
const STORE_NAME = "pending-entries";
const SNAPSHOT_STORE = "overview-snapshots";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("Offline storage is unavailable in this browser."));
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "mutationId" });
        store.createIndex("userId", "userId", { unique: false });
      }
      if (!db.objectStoreNames.contains(SNAPSHOT_STORE)) db.createObjectStore(SNAPSHOT_STORE, { keyPath: "userId" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open offline storage."));
  });
}

export async function listPendingEntries(userId: number): Promise<OfflineEntry[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).index("userId").getAll(IDBKeyRange.only(userId));
    request.onsuccess = () => resolve((request.result as OfflineEntry[]).sort((a, b) => a.createdAt - b.createdAt));
    request.onerror = () => reject(request.error);
  });
}

export async function savePendingEntry(entry: OfflineEntry): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).put(entry);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function removePendingEntry(mutationId: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).delete(mutationId);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function saveOverviewSnapshot(userId: number, overview: unknown): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(SNAPSHOT_STORE, "readwrite").objectStore(SNAPSHOT_STORE).put({ userId, overview, savedAt: Date.now() });
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getOverviewSnapshot<T>(userId: number): Promise<T | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(SNAPSHOT_STORE, "readonly").objectStore(SNAPSHOT_STORE).get(userId);
    request.onsuccess = () => resolve((request.result?.overview as T) ?? null);
    request.onerror = () => reject(request.error);
  });
}
