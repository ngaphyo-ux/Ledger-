import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

const moneySchema = z.string().regex(/^\d+(\.\d{1,2})?$/, "Use a non-negative amount with up to two decimals");
const amountSchema = moneySchema.refine(value => Number(value) > 0, "Amount must be greater than zero");
const openingBalanceSchema = moneySchema;
const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");

const accountFields = z.object({
  name: z.string().trim().min(1).max(120),
  institution: z.string().trim().min(1).max(120),
  lastFour: z.string().trim().max(4).optional().nullable(),
  openingBalance: openingBalanceSchema,
});

const categoryFields = z.object({
  name: z.string().trim().min(1).max(80),
  type: z.enum(["income", "expense", "both"]),
  color: z.string().trim().min(4).max(20),
});

const entryFields = z.object({
  accountId: z.number().int().positive(),
  categoryId: z.number().int().positive().optional().nullable(),
  entryType: z.enum(["statement", "cash"]),
  flow: z.enum(["in", "out"]),
  amount: amountSchema,
  entryDate: dateSchema,
  description: z.string().trim().min(1).max(180),
  remarks: z.string().trim().max(2000).optional().nullable(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  finance: router({
    overview: protectedProcedure.query(({ ctx }) => db.getFinanceOverview(ctx.user.id)),
    createAccount: protectedProcedure.input(accountFields).mutation(({ ctx, input }) =>
      db.createBankAccount(ctx.user.id, {
        ...input,
        lastFour: input.lastFour || null,
      })
    ),
    updateAccount: protectedProcedure
      .input(z.object({ id: z.number().int().positive(), data: accountFields }))
      .mutation(({ ctx, input }) =>
        db.updateBankAccount(ctx.user.id, input.id, {
          ...input.data,
          lastFour: input.data.lastFour || null,
        })
      ),
    createCategory: protectedProcedure.input(categoryFields).mutation(({ ctx, input }) => db.createCategory(ctx.user.id, input)),
    updateCategory: protectedProcedure
      .input(z.object({ id: z.number().int().positive(), data: categoryFields }))
      .mutation(({ ctx, input }) => db.updateCategory(ctx.user.id, input.id, input.data)),
    createEntry: protectedProcedure.input(entryFields).mutation(({ ctx, input }) =>
      db.createLedgerEntry(ctx.user.id, {
        ...input,
        categoryId: input.categoryId || null,
        remarks: input.remarks || null,
      })
    ),
    updateEntry: protectedProcedure
      .input(z.object({ id: z.number().int().positive(), data: entryFields }))
      .mutation(({ ctx, input }) =>
        db.updateLedgerEntry(ctx.user.id, input.id, {
          ...input.data,
          categoryId: input.data.categoryId || null,
          remarks: input.data.remarks || null,
        })
      ),
  }),
});

export type AppRouter = typeof appRouter;
