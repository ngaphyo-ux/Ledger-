import { and, asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  bankAccounts,
  categories,
  InsertBankAccount,
  InsertCategory,
  InsertLedgerEntry,
  ledgerEntries,
  InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requireDb() {
  if (!_db) throw new Error("Database is not available");
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

async function assertLedgerReferences(userId: number, accountId: number, categoryId?: number | null) {
  const db = requireDb();
  const account = await db
    .select({ id: bankAccounts.id })
    .from(bankAccounts)
    .where(and(eq(bankAccounts.id, accountId), eq(bankAccounts.userId, userId)))
    .limit(1);
  if (account.length === 0) throw new Error("Bank account not found");

  if (categoryId) {
    const category = await db
      .select({ id: categories.id })
      .from(categories)
      .where(and(eq(categories.id, categoryId), eq(categories.userId, userId)))
      .limit(1);
    if (category.length === 0) throw new Error("Category not found");
  }
}

async function ensureDefaultCategories(userId: number) {
  const db = requireDb();
  const existing = await db.select({ id: categories.id }).from(categories).where(eq(categories.userId, userId)).limit(1);
  if (existing.length > 0) return;

  await db.insert(categories).values([
    { userId, name: "Salary", type: "income", color: "#6EE7B7" },
    { userId, name: "Transfer in", type: "income", color: "#7DD3FC" },
    { userId, name: "Groceries", type: "expense", color: "#F4B942" },
    { userId, name: "Bills", type: "expense", color: "#FB7185" },
    { userId, name: "Transport", type: "expense", color: "#C4B5FD" },
    { userId, name: "Other", type: "both", color: "#A7F3D0" },
  ]);
}

export async function getFinanceOverview(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await ensureDefaultCategories(userId);

  const [accounts, userCategories, entries] = await Promise.all([
    db.select().from(bankAccounts).where(eq(bankAccounts.userId, userId)).orderBy(asc(bankAccounts.name)),
    db.select().from(categories).where(eq(categories.userId, userId)).orderBy(asc(categories.name)),
    db
      .select({
        id: ledgerEntries.id,
        accountId: ledgerEntries.accountId,
        accountName: bankAccounts.name,
        categoryId: ledgerEntries.categoryId,
        categoryName: categories.name,
        categoryColor: categories.color,
        entryType: ledgerEntries.entryType,
        flow: ledgerEntries.flow,
        amount: ledgerEntries.amount,
        entryDate: ledgerEntries.entryDate,
        description: ledgerEntries.description,
        remarks: ledgerEntries.remarks,
        createdAt: ledgerEntries.createdAt,
      })
      .from(ledgerEntries)
      .leftJoin(bankAccounts, eq(ledgerEntries.accountId, bankAccounts.id))
      .leftJoin(categories, eq(ledgerEntries.categoryId, categories.id))
      .where(eq(ledgerEntries.userId, userId))
      .orderBy(desc(ledgerEntries.entryDate), desc(ledgerEntries.id)),
  ]);

  return { accounts, categories: userCategories, entries };
}

export async function createBankAccount(userId: number, input: Omit<InsertBankAccount, "userId">) {
  const db = requireDb();
  return db.insert(bankAccounts).values({ ...input, userId });
}

export async function updateBankAccount(userId: number, id: number, input: Partial<Omit<InsertBankAccount, "userId">>) {
  const db = requireDb();
  return db.update(bankAccounts).set(input).where(and(eq(bankAccounts.id, id), eq(bankAccounts.userId, userId)));
}

export async function createCategory(userId: number, input: Omit<InsertCategory, "userId">) {
  const db = requireDb();
  return db.insert(categories).values({ ...input, userId });
}

export async function updateCategory(userId: number, id: number, input: Partial<Omit<InsertCategory, "userId">>) {
  const db = requireDb();
  return db.update(categories).set(input).where(and(eq(categories.id, id), eq(categories.userId, userId)));
}

export async function createLedgerEntry(userId: number, input: Omit<InsertLedgerEntry, "userId">) {
  const db = requireDb();
  await assertLedgerReferences(userId, input.accountId, input.categoryId);
  return db.insert(ledgerEntries).values({ ...input, userId });
}

export async function updateLedgerEntry(userId: number, id: number, input: Partial<Omit<InsertLedgerEntry, "userId">>) {
  const db = requireDb();
  if (input.accountId !== undefined) {
    await assertLedgerReferences(userId, input.accountId, input.categoryId);
  } else if (input.categoryId) {
    await assertLedgerReferences(userId, input.accountId ?? 0, input.categoryId);
  }
  return db.update(ledgerEntries).set(input).where(and(eq(ledgerEntries.id, id), eq(ledgerEntries.userId, userId)));
}
