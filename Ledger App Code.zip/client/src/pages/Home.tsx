import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  BarChart3,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleDollarSign,
  CloudOff,
  Download,
  Edit3,
  Landmark,
  LayoutDashboard,
  ListFilter,
  LogOut,
  Menu,
  Plus,
  RefreshCw,
  Settings2,
  ShieldCheck,
  Tag,
  WalletCards,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

type View = "overview" | "entries" | "accounts" | "categories";
type EntryFlow = "in" | "out";
type EntryType = "statement" | "cash";
type CategoryType = "income" | "expense" | "both";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type EntryDraft = {
  id?: number;
  accountId: string;
  categoryId: string;
  entryType: EntryType;
  flow: EntryFlow;
  amount: string;
  entryDate: string;
  description: string;
  remarks: string;
};

type AccountDraft = {
  id?: number;
  name: string;
  institution: string;
  lastFour: string;
  openingBalance: string;
};

type CategoryDraft = {
  id?: number;
  name: string;
  type: CategoryType;
  color: string;
};

const today = new Date().toISOString().slice(0, 10);
const emptyEntry: EntryDraft = {
  accountId: "",
  categoryId: "",
  entryType: "cash",
  flow: "out",
  amount: "",
  entryDate: today,
  description: "",
  remarks: "",
};
const emptyAccount: AccountDraft = {
  name: "",
  institution: "",
  lastFour: "",
  openingBalance: "0",
};
const emptyCategory: CategoryDraft = {
  name: "",
  type: "both",
  color: "#F4B942",
};

function formatAmount(value: number | string) {
  const amount = Number(value || 0);
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

function initials(name?: string | null) {
  return (name || "You")
    .split(" ")
    .map(part => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(
    new Date(`${value}T12:00:00`)
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label className="field-label">{children}</label>;
}

function EmptyState({ title, description, action }: { title: string; description: string; action?: React.ReactNode }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon"><WalletCards size={20} /></div>
      <div>
        <p className="empty-state-title">{title}</p>
        <p className="empty-state-copy">{description}</p>
      </div>
      {action}
    </div>
  );
}

export default function Home() {
  const { user, loading: authLoading, logout } = useAuth();
  const [activeView, setActiveView] = useState<View>("overview");
  const [entryDraft, setEntryDraft] = useState<EntryDraft>(emptyEntry);
  const [accountDraft, setAccountDraft] = useState<AccountDraft>(emptyAccount);
  const [categoryDraft, setCategoryDraft] = useState<CategoryDraft>(emptyCategory);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isOnline, setIsOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine);

  const utils = trpc.useUtils();
  const overviewQuery = trpc.finance.overview.useQuery(undefined, {
    enabled: Boolean(user),
    retry: false,
    refetchOnWindowFocus: false,
  });

  const refresh = () => utils.finance.overview.invalidate();
  const createEntry = trpc.finance.createEntry.useMutation({ onSuccess: refresh });
  const updateEntry = trpc.finance.updateEntry.useMutation({ onSuccess: refresh });
  const createAccount = trpc.finance.createAccount.useMutation({ onSuccess: refresh });
  const updateAccount = trpc.finance.updateAccount.useMutation({ onSuccess: refresh });
  const createCategory = trpc.finance.createCategory.useMutation({ onSuccess: refresh });
  const updateCategory = trpc.finance.updateCategory.useMutation({ onSuccess: refresh });

  const overview = overviewQuery.data;
  const accounts = overview?.accounts ?? [];
  const categories = overview?.categories ?? [];
  const entries = overview?.entries ?? [];

  const totals = useMemo(() => {
    const totalIn = entries.filter(entry => entry.flow === "in").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const totalOut = entries.filter(entry => entry.flow === "out").reduce((sum, entry) => sum + Number(entry.amount), 0);
    const accountBalances = accounts.map(account => {
      const movement = entries
        .filter(entry => entry.accountId === account.id)
        .reduce((sum, entry) => sum + (entry.flow === "in" ? Number(entry.amount) : -Number(entry.amount)), 0);
      return { ...account, balance: Number(account.openingBalance) + movement };
    });
    return { totalIn, totalOut, net: totalIn - totalOut, accountBalances };
  }, [accounts, entries]);

  useEffect(() => {
    const onBeforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) {
      toast.info("Use your browser menu and choose Add to Home Screen to install Ledgerly.");
      return;
    }
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") toast.success("Ledgerly is ready on your home screen.");
    setInstallPrompt(null);
  };

  const resetEntry = () => setEntryDraft({ ...emptyEntry, accountId: accounts[0] ? String(accounts[0].id) : "" });
  const resetAccount = () => setAccountDraft(emptyAccount);
  const resetCategory = () => setCategoryDraft(emptyCategory);

  const handleEntrySubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!entryDraft.accountId) return toast.error("Add a bank account before recording a transaction.");
    if (!entryDraft.amount || Number(entryDraft.amount) <= 0) return toast.error("Enter an amount greater than zero.");
    const payload = {
      accountId: Number(entryDraft.accountId),
      categoryId: entryDraft.categoryId ? Number(entryDraft.categoryId) : null,
      entryType: entryDraft.entryType,
      flow: entryDraft.flow,
      amount: entryDraft.amount,
      entryDate: entryDraft.entryDate,
      description: entryDraft.description.trim(),
      remarks: entryDraft.remarks.trim() || null,
    };
    if (!payload.description) return toast.error("Add a short description for this record.");

    const onSuccess = () => {
      toast.success(entryDraft.id ? "Record updated." : "Record added.");
      resetEntry();
    };
    if (entryDraft.id) {
      updateEntry.mutate({ id: entryDraft.id, data: payload }, { onSuccess });
    } else {
      createEntry.mutate(payload, { onSuccess });
    }
  };

  const handleAccountSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!accountDraft.name.trim() || !accountDraft.institution.trim()) return toast.error("Add an account name and institution.");
    const payload = {
      name: accountDraft.name.trim(),
      institution: accountDraft.institution.trim(),
      lastFour: accountDraft.lastFour.trim() || null,
      openingBalance: accountDraft.openingBalance || "0",
    };
    const onSuccess = () => {
      toast.success(accountDraft.id ? "Bank account updated." : "Bank account added.");
      resetAccount();
    };
    if (accountDraft.id) updateAccount.mutate({ id: accountDraft.id, data: payload }, { onSuccess });
    else createAccount.mutate(payload, { onSuccess });
  };

  const handleCategorySubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!categoryDraft.name.trim()) return toast.error("Name this category first.");
    const payload = { ...categoryDraft, name: categoryDraft.name.trim() };
    const onSuccess = () => {
      toast.success(categoryDraft.id ? "Category updated." : "Category added.");
      resetCategory();
    };
    if (categoryDraft.id) updateCategory.mutate({ id: categoryDraft.id, data: payload }, { onSuccess });
    else createCategory.mutate(payload, { onSuccess });
  };

  if (authLoading) {
    return <div className="app-loading"><RefreshCw className="spin" size={22} /><span>Loading your Ledgerly workspace…</span></div>;
  }

  if (!user) {
    return (
      <div className="login-shell">
        <div className="login-grid" />
        <div className="login-card">
          <div className="brand-lockup"><div className="brand-mark"><Landmark size={22} /></div><span>LEDGERLY</span></div>
          <div className="login-kicker">PRIVATE FINANCE OPERATING SYSTEM</div>
          <h1>See every account.<br /><em>Know your position.</em></h1>
          <p className="login-copy">Bring bank statements, cash movement, categories, and remarks into one calm control panel built for your pocket.</p>
          <Button className="login-button" size="lg" onClick={() => startLogin()}><ShieldCheck size={18} /> Sign in securely</Button>
          <div className="login-note"><Check size={14} /> Your records stay scoped to your signed-in account.</div>
        </div>
      </div>
    );
  }

  if (overviewQuery.isLoading) {
    return <div className="app-loading"><RefreshCw className="spin" size={22} /><span>Loading your ledger…</span></div>;
  }

  const navItems: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "entries", label: "Activity", icon: ListFilter },
    { id: "accounts", label: "Accounts", icon: Landmark },
    { id: "categories", label: "Categories", icon: Tag },
  ];

  const renderEntryForm = () => {
    const isSaving = createEntry.isPending || updateEntry.isPending;
    const compatibleCategories = categories.filter(category => category.type === "both" || (entryDraft.flow === "in" ? category.type === "income" : category.type === "expense"));
    return (
      <Card className="composer-card" id="entry-form">
        <CardHeader className="composer-header">
          <div><div className="eyebrow">{entryDraft.id ? "EDIT RECORD" : "QUICK CAPTURE"}</div><CardTitle>{entryDraft.id ? "Update movement" : "Add a transaction"}</CardTitle></div>
          {entryDraft.id && <Button variant="ghost" size="icon" onClick={resetEntry} aria-label="Cancel editing"><X size={18} /></Button>}
        </CardHeader>
        <CardContent>
          <form className="form-stack" onSubmit={handleEntrySubmit}>
            <div className="segmented-control">
              <button type="button" className={entryDraft.entryType === "cash" ? "selected" : ""} onClick={() => setEntryDraft(prev => ({ ...prev, entryType: "cash" }))}><Banknote size={15} /> Cash movement</button>
              <button type="button" className={entryDraft.entryType === "statement" ? "selected" : ""} onClick={() => setEntryDraft(prev => ({ ...prev, entryType: "statement" }))}><Landmark size={15} /> Bank statement</button>
            </div>
            <div className="flow-toggle">
              <button type="button" className={entryDraft.flow === "in" ? "in selected" : "in"} onClick={() => setEntryDraft(prev => ({ ...prev, flow: "in", categoryId: "" }))}><ArrowDownLeft size={16} /> Cash in</button>
              <button type="button" className={entryDraft.flow === "out" ? "out selected" : "out"} onClick={() => setEntryDraft(prev => ({ ...prev, flow: "out", categoryId: "" }))}><ArrowUpRight size={16} /> Cash out</button>
            </div>
            <div className="form-grid two">
              <div><FieldLabel>Amount</FieldLabel><div className="amount-input"><span>¤</span><input required inputMode="decimal" type="number" min="0.01" step="0.01" placeholder="0.00" value={entryDraft.amount} onChange={event => setEntryDraft(prev => ({ ...prev, amount: event.target.value }))} /></div></div>
              <div><FieldLabel>Date</FieldLabel><input required className="field-input" type="date" value={entryDraft.entryDate} onChange={event => setEntryDraft(prev => ({ ...prev, entryDate: event.target.value }))} /></div>
            </div>
            <div className="form-grid two">
              <div><FieldLabel>Bank account</FieldLabel><select required className="field-select" value={entryDraft.accountId} onChange={event => setEntryDraft(prev => ({ ...prev, accountId: event.target.value }))}><option value="">Select account</option>{accounts.map(account => <option key={account.id} value={account.id}>{account.name} · {account.institution}</option>)}</select></div>
              <div><FieldLabel>Category</FieldLabel><select className="field-select" value={entryDraft.categoryId} onChange={event => setEntryDraft(prev => ({ ...prev, categoryId: event.target.value }))}><option value="">Uncategorized</option>{compatibleCategories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}</select></div>
            </div>
            <div><FieldLabel>{entryDraft.entryType === "statement" ? "Statement description" : "What was this for?"}</FieldLabel><input required className="field-input" placeholder={entryDraft.entryType === "statement" ? "e.g. ATM withdrawal, salary credit" : "e.g. Lunch, freelance payment"} value={entryDraft.description} onChange={event => setEntryDraft(prev => ({ ...prev, description: event.target.value }))} /></div>
            <div><FieldLabel>Remarks <span className="optional">OPTIONAL</span></FieldLabel><textarea className="field-input field-textarea" rows={3} placeholder="Add context for your future self…" value={entryDraft.remarks} onChange={event => setEntryDraft(prev => ({ ...prev, remarks: event.target.value }))} /></div>
            <Button type="submit" className="wide-button" disabled={isSaving || accounts.length === 0}>{isSaving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{entryDraft.id ? "Update record" : "Save record"}</Button>
            {accounts.length === 0 && <p className="form-hint">Add a bank account first, then you can assign records to it.</p>}
          </form>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="app-shell">
      <aside className="desktop-rail">
        <div className="rail-brand"><div className="brand-mark"><Landmark size={18} /></div><span>LEDGERLY</span></div>
        <div className="rail-section-label">WORKSPACE</div>
        <nav className="rail-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={activeView === item.id ? "active" : ""} onClick={() => setActiveView(item.id)}><Icon size={17} /><span>{item.label}</span>{activeView === item.id && <ChevronRight className="nav-arrow" size={15} />}</button>; })}</nav>
        <div className="rail-spacer" />
        <div className="rail-status"><span className={isOnline ? "status-dot online" : "status-dot"} />{isOnline ? "SYNC READY" : "OFFLINE MODE"}<span className="status-line" /></div>
        <button className="rail-account" onClick={() => logout()}><span className="avatar">{initials(user.name)}</span><span className="account-copy"><strong>{user.name || "My workspace"}</strong><small>Sign out</small></span><LogOut size={15} /></button>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <div className="mobile-brand">
            <div className="brand-mark"><Landmark size={17} /></div>
            <span>LEDGERLY</span>
          </div>
          <div className="topbar-meta">
            <span className={isOnline ? "online-label" : "offline-label"}>
              {isOnline ? <Check size={13} /> : <CloudOff size={13} />}
              {isOnline ? "ALL SYSTEMS SYNCED" : "WORKING OFFLINE"}
            </span>
            <Button variant="outline" size="sm" onClick={handleInstall}>
              <Download size={15} /> Install app
            </Button>
            <button className="topbar-avatar" onClick={() => logout()}>{initials(user.name)}</button>
          </div>
        </header>
        <div className="mobile-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} className={activeView === item.id ? "active" : ""} onClick={() => setActiveView(item.id)}><Icon size={17} /><span>{item.label}</span></button>; })}</div>

        <div className="page-wrap">
          <section className="page-heading"><div><p className="eyebrow">PERSONAL FINANCE / {new Intl.DateTimeFormat("en", { month: "short", year: "numeric" }).format(new Date()).toUpperCase()}</p><h1>{activeView === "overview" ? "Aye Pa Pa Aung Account" : activeView === "entries" ? "Activity log" : activeView === "accounts" ? "Bank accounts" : "Categories"}</h1><p className="heading-copy">{activeView === "overview" ? "A clean read on where your money stands today." : activeView === "entries" ? "Bank statements and cash movements, all in one timeline." : activeView === "accounts" ? "Keep every individual account visible and assignable." : "Make your own language for cash in and cash out."}</p></div><div className="heading-actions"><Button variant="outline" size="sm" onClick={() => refresh()} disabled={overviewQuery.isFetching}><RefreshCw className={overviewQuery.isFetching ? "spin" : ""} size={15} /> Sync</Button><Button size="sm" onClick={() => { setActiveView("entries"); resetEntry(); document.getElementById("entry-form")?.scrollIntoView({ behavior: "smooth" }); }}><Plus size={15} /> Add record</Button></div></section>

          {overviewQuery.error && <div className="error-strip">We could not load your ledger. Refresh to retry. <button onClick={() => refresh()}>Try again</button></div>}

          {activeView === "overview" && <>
            <section className="metric-grid"><Card className="metric-card balance-card"><CardContent><div className="metric-top"><span className="metric-label">TOTAL POSITION</span><CircleDollarSign size={18} /></div><div className="metric-value">¤ {formatAmount(totals.accountBalances.reduce((sum, account) => sum + account.balance, 0))}</div><div className="metric-sub">Across {accounts.length} connected account{accounts.length === 1 ? "" : "s"}</div></CardContent></Card><Card className="metric-card"><CardContent><div className="metric-top"><span className="metric-label">MONEY IN</span><ArrowDownLeft size={18} className="green-icon" /></div><div className="metric-value">¤ {formatAmount(totals.totalIn)}</div><div className="metric-sub">From all recorded activity</div></CardContent></Card><Card className="metric-card"><CardContent><div className="metric-top"><span className="metric-label">MONEY OUT</span><ArrowUpRight size={18} className="red-icon" /></div><div className="metric-value">¤ {formatAmount(totals.totalOut)}</div><div className="metric-sub">From all recorded activity</div></CardContent></Card><Card className="metric-card"><CardContent><div className="metric-top"><span className="metric-label">NET MOVEMENT</span><BarChart3 size={18} /></div><div className={totals.net >= 0 ? "metric-value positive" : "metric-value negative"}>¤ {formatAmount(totals.net)}</div><div className="metric-sub">In minus out</div></CardContent></Card></section>
            <section className="dashboard-grid"><div className="dashboard-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">LATEST SIGNALS</div><CardTitle>Recent activity</CardTitle></div><button className="text-action" onClick={() => setActiveView("entries")}>View all <ChevronRight size={14} /></button></CardHeader><CardContent className="flush-content">{entries.length === 0 ? <EmptyState title="Your timeline is clear" description="Add a bank account, then capture your first statement or cash movement." action={<Button size="sm" onClick={() => setActiveView("accounts")}><Plus size={14} /> Add account</Button>} /> : <div className="entry-list">{entries.slice(0, 6).map(entry => <EntryRow key={entry.id} entry={entry} onEdit={() => { setEntryDraft({ id: entry.id, accountId: String(entry.accountId), categoryId: entry.categoryId ? String(entry.categoryId) : "", entryType: entry.entryType, flow: entry.flow, amount: String(entry.amount), entryDate: entry.entryDate, description: entry.description, remarks: entry.remarks || "" }); setActiveView("entries"); setTimeout(() => document.getElementById("entry-form")?.scrollIntoView({ behavior: "smooth" }), 50); }} />)}</div>}</CardContent></Card><Card className="panel-card account-summary"><CardHeader className="panel-heading"><div><div className="eyebrow">ACCOUNT PULSE</div><CardTitle>By account</CardTitle></div><button className="icon-button" onClick={() => setActiveView("accounts")} aria-label="Manage accounts"><Settings2 size={16} /></button></CardHeader><CardContent className="flush-content">{accounts.length === 0 ? <EmptyState title="No accounts yet" description="Create your first account to start assigning activity." /> : <div className="account-list">{totals.accountBalances.map(account => <div className="account-row" key={account.id}><span className="account-icon"><Landmark size={16} /></span><span className="account-info"><strong>{account.name}</strong><small>{account.institution}{account.lastFour ? ` ··${account.lastFour}` : ""}</small></span><strong className="account-balance">¤ {formatAmount(account.balance)}</strong></div>)}</div>}</CardContent></Card></div><div className="dashboard-side">{renderEntryForm()}</div></section>
          </>}

          {activeView === "entries" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">LEDGER TIMELINE</div><CardTitle>All activity</CardTitle></div><div className="entry-count">{entries.length} RECORD{entries.length === 1 ? "" : "S"}</div></CardHeader><CardContent className="flush-content">{entries.length === 0 ? <EmptyState title="No activity recorded" description="Use the capture panel to add a bank statement or cash movement." /> : <div className="entry-list">{entries.map(entry => <EntryRow key={entry.id} entry={entry} onEdit={() => setEntryDraft({ id: entry.id, accountId: String(entry.accountId), categoryId: entry.categoryId ? String(entry.categoryId) : "", entryType: entry.entryType, flow: entry.flow, amount: String(entry.amount), entryDate: entry.entryDate, description: entry.description, remarks: entry.remarks || "" })} />)}</div>}</CardContent></Card></div><div className="content-side">{renderEntryForm()}</div></section>}

          {activeView === "accounts" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">CONNECTED ACCOUNTS</div><CardTitle>Every bank in one view</CardTitle></div><div className="entry-count">{accounts.length} ACCOUNT{accounts.length === 1 ? "" : "S"}</div></CardHeader><CardContent className="flush-content">{accounts.length === 0 ? <EmptyState title="Start with an account" description="Add your current or savings account so every future record has a home." /> : <div className="account-cards">{totals.accountBalances.map(account => <div className="account-card" key={account.id}><div className="account-card-top"><span className="account-icon large"><Landmark size={19} /></span><button className="icon-button" aria-label={`Edit ${account.name}`} onClick={() => setAccountDraft({ id: account.id, name: account.name, institution: account.institution, lastFour: account.lastFour || "", openingBalance: String(account.openingBalance) })}><Edit3 size={15} /></button></div><div className="account-card-name">{account.name}</div><div className="account-card-institution">{account.institution}{account.lastFour ? ` ··${account.lastFour}` : ""}</div><div className="account-card-balance">¤ {formatAmount(account.balance)}</div><div className="account-card-foot"><span>Opening balance</span><span>¤ {formatAmount(account.openingBalance)}</span></div></div>)}</div>}</CardContent></Card></div><div className="content-side"><AccountForm draft={accountDraft} setDraft={setAccountDraft} onSubmit={handleAccountSubmit} onCancel={resetAccount} saving={createAccount.isPending || updateAccount.isPending} /></div></section>}

          {activeView === "categories" && <section className="content-grid"><div className="content-main"><Card className="panel-card"><CardHeader className="panel-heading"><div><div className="eyebrow">YOUR VOCABULARY</div><CardTitle>Categories</CardTitle></div><div className="entry-count">{categories.length} TAG{categories.length === 1 ? "" : "S"}</div></CardHeader><CardContent className="flush-content"><div className="category-list">{categories.map(category => <div className="category-row" key={category.id}><span className="category-dot" style={{ background: category.color }} /><span className="category-name">{category.name}</span><span className={`category-type ${category.type}`}>{category.type === "both" ? "IN + OUT" : category.type.toUpperCase()}</span><button className="icon-button" onClick={() => setCategoryDraft({ id: category.id, name: category.name, type: category.type, color: category.color })} aria-label={`Edit ${category.name}`}><Edit3 size={15} /></button></div>)}</div></CardContent></Card></div><div className="content-side"><CategoryForm draft={categoryDraft} setDraft={setCategoryDraft} onSubmit={handleCategorySubmit} onCancel={resetCategory} saving={createCategory.isPending || updateCategory.isPending} /></div></section>}
        </div>
      </main>
    </div>
  );
}

function EntryRow({ entry, onEdit }: { entry: { id: number; accountName: string | null; categoryName: string | null; categoryColor: string | null; entryType: EntryType; flow: EntryFlow; amount: string; entryDate: string; description: string; remarks: string | null }; onEdit: () => void }) {
  return <div className="entry-row"><span className={`entry-icon ${entry.flow}`}><>{entry.flow === "in" ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}</></span><span className="entry-info"><strong>{entry.description}</strong><small>{entry.accountName || "Unassigned account"} · {entry.categoryName || "Uncategorized"} · {entry.entryType === "statement" ? "Statement" : "Cash"}</small></span><span className="entry-date">{formatDate(entry.entryDate)}</span><strong className={`entry-amount ${entry.flow}`}>{entry.flow === "in" ? "+" : "−"}¤ {formatAmount(entry.amount)}</strong><button className="icon-button edit-entry" onClick={onEdit} aria-label={`Edit ${entry.description}`}><Edit3 size={14} /></button></div>;
}

function AccountForm({ draft, setDraft, onSubmit, onCancel, saving }: { draft: AccountDraft; setDraft: (value: AccountDraft) => void; onSubmit: (event: FormEvent) => void; onCancel: () => void; saving: boolean }) {
  return <Card className="composer-card"><CardHeader className="composer-header"><div><div className="eyebrow">{draft.id ? "EDIT ACCOUNT" : "NEW ACCOUNT"}</div><CardTitle>{draft.id ? "Update account" : "Add bank account"}</CardTitle></div>{draft.id && <Button variant="ghost" size="icon" onClick={onCancel}><X size={18} /></Button>}</CardHeader><CardContent><form className="form-stack" onSubmit={onSubmit}><div><FieldLabel>Account name</FieldLabel><input required className="field-input" placeholder="e.g. Daily spending" value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></div><div><FieldLabel>Bank or institution</FieldLabel><input required className="field-input" placeholder="e.g. Metro Bank" value={draft.institution} onChange={event => setDraft({ ...draft, institution: event.target.value })} /></div><div className="form-grid two"><div><FieldLabel>Last 4 digits <span className="optional">OPTIONAL</span></FieldLabel><input className="field-input" inputMode="numeric" maxLength={4} placeholder="4821" value={draft.lastFour} onChange={event => setDraft({ ...draft, lastFour: event.target.value.replace(/\D/g, "").slice(0, 4) })} /></div><div><FieldLabel>Opening balance</FieldLabel><input required className="field-input" inputMode="decimal" type="number" step="0.01" min="0" value={draft.openingBalance} onChange={event => setDraft({ ...draft, openingBalance: event.target.value })} /></div></div><Button type="submit" className="wide-button" disabled={saving}>{saving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{draft.id ? "Update account" : "Save account"}</Button></form></CardContent></Card>;
}

function CategoryForm({ draft, setDraft, onSubmit, onCancel, saving }: { draft: CategoryDraft; setDraft: (value: CategoryDraft) => void; onSubmit: (event: FormEvent) => void; onCancel: () => void; saving: boolean }) {
  return <Card className="composer-card"><CardHeader className="composer-header"><div><div className="eyebrow">{draft.id ? "EDIT CATEGORY" : "NEW CATEGORY"}</div><CardTitle>{draft.id ? "Update category" : "Add category"}</CardTitle></div>{draft.id && <Button variant="ghost" size="icon" onClick={onCancel}><X size={18} /></Button>}</CardHeader><CardContent><form className="form-stack" onSubmit={onSubmit}><div><FieldLabel>Category name</FieldLabel><input required className="field-input" placeholder="e.g. Subscriptions" value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></div><div><FieldLabel>Used for</FieldLabel><select className="field-select" value={draft.type} onChange={event => setDraft({ ...draft, type: event.target.value as CategoryType })}><option value="both">Cash in + cash out</option><option value="income">Cash in only</option><option value="expense">Cash out only</option></select></div><div><FieldLabel>Accent color</FieldLabel><div className="color-row"><input className="color-input" type="color" value={draft.color} onChange={event => setDraft({ ...draft, color: event.target.value })} /><span>{draft.color}</span></div></div><Button type="submit" className="wide-button" disabled={saving}>{saving ? <RefreshCw className="spin" size={16} /> : <Plus size={17} />}{draft.id ? "Update category" : "Save category"}</Button></form></CardContent></Card>;
}
