# Ledgerly — Private Finance Tracker

A private, mobile-first personal finance workspace for manually recording bank accounts, bank-statement entries, and cash movements. Each signed-in user's records are persisted in the managed database and remain scoped to that user. Ledgerly does not connect to banks or import or upload statements.

The interface follows the reference app's Signal Deck direction and includes Overview, Activity, Accounts, and Categories views, plus its installable PWA shell.

## Development

- `pnpm dev` — start the React/Express app on the configured runtime port.
- `pnpm check` — run TypeScript checks.
- `pnpm test` — run the test suite.
- `pnpm build` — build the frontend and server.
- `pnpm db:migrate` — apply checked-in Drizzle migrations.

The application uses Manus OAuth and server-side user-scoped access checks. Development and published runtime share the managed database; database changes should be additive and migrations should be reviewed before running.
